import abc
import builtins
import datetime
import enum
import typing

import jsii
import jsii.compat
import publication

import aws_cdk.core
import aws_cdk.cx_api

__jsii_assembly__ = jsii.JSIIAssembly.load("@terrastack/core", "0.15.0", __name__, "core@0.15.0.jsii.tgz")


class App(aws_cdk.core.Construct, metaclass=jsii.JSIIMeta, jsii_type="@terrastack/core.App"):
    """Represents a cdk8s application.

    stability
    :stability: experimental
    """
    def __init__(self, *, outdir: typing.Optional[str]=None) -> None:
        """Defines an app.

        :param outdir: The directory to output Kubernetes manifests. Default: "dist"

        stability
        :stability: experimental
        """
        options = AppOptions(outdir=outdir)

        jsii.create(App, self, [options])

    @jsii.member(jsii_name="synth")
    def synth(self) -> None:
        """Synthesizes all manifests to the output directory.

        stability
        :stability: experimental
        """
        return jsii.invoke(self, "synth", [])

    @builtins.property
    @jsii.member(jsii_name="outdir")
    def outdir(self) -> str:
        """The output directory into which manifests will be synthesized.

        stability
        :stability: experimental
        """
        return jsii.get(self, "outdir")


@jsii.data_type(jsii_type="@terrastack/core.AppOptions", jsii_struct_bases=[], name_mapping={'outdir': 'outdir'})
class AppOptions():
    def __init__(self, *, outdir: typing.Optional[str]=None):
        """
        :param outdir: The directory to output Kubernetes manifests. Default: "dist"

        stability
        :stability: experimental
        """
        self._values = {
        }
        if outdir is not None: self._values["outdir"] = outdir

    @builtins.property
    def outdir(self) -> typing.Optional[str]:
        """The directory to output Kubernetes manifests.

        default
        :default: "dist"

        stability
        :stability: experimental
        """
        return self._values.get('outdir')

    def __eq__(self, rhs) -> bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs) -> bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return 'AppOptions(%s)' % ', '.join(k + '=' + repr(v) for k, v in self._values.items())


@jsii.interface(jsii_type="@terrastack/core.IReferencableResource")
class IReferencableResource(jsii.compat.Protocol):
    """
    stability
    :stability: experimental
    """
    @builtins.staticmethod
    def __jsii_proxy_class__():
        return _IReferencableResourceProxy

    @jsii.member(jsii_name="logicalId")
    def logical_id(self) -> str:
        """
        stability
        :stability: experimental
        """
        ...


class _IReferencableResourceProxy():
    """
    stability
    :stability: experimental
    """
    __jsii_type__ = "@terrastack/core.IReferencableResource"
    @jsii.member(jsii_name="logicalId")
    def logical_id(self) -> str:
        """
        stability
        :stability: experimental
        """
        return jsii.invoke(self, "logicalId", [])


@jsii.implements(IReferencableResource)
class ResourceObject(aws_cdk.core.Construct, metaclass=jsii.JSIIMeta, jsii_type="@terrastack/core.ResourceObject"):
    """
    stability
    :stability: experimental
    """
    def __init__(self, scope: aws_cdk.core.Construct, ns: str, props: "ResourceObjectProps", *, name: str, provider_name: str, provider_version: str, raw_schema: str, schema_type: "TerraformSchemaType") -> None:
        """Defines an API object.

        :param scope: the construct scope.
        :param ns: namespace.
        :param props: options.
        :param name: 
        :param provider_name: 
        :param provider_version: 
        :param raw_schema: 
        :param schema_type: 

        stability
        :stability: experimental
        """
        terraform = TerraformMetadata(name=name, provider_name=provider_name, provider_version=provider_version, raw_schema=raw_schema, schema_type=schema_type)

        jsii.create(ResourceObject, self, [scope, ns, props, terraform])

    @jsii.member(jsii_name="logicalId")
    def logical_id(self) -> str:
        """
        stability
        :stability: experimental
        """
        return jsii.invoke(self, "logicalId", [])

    @builtins.property
    @jsii.member(jsii_name="terraform")
    def terraform(self) -> "TerraformMetadata":
        """
        stability
        :stability: experimental
        """
        return jsii.get(self, "terraform")

    @builtins.property
    @jsii.member(jsii_name="tfProperties")
    def _tf_properties(self) -> typing.Mapping[str,typing.Any]:
        """
        stability
        :stability: experimental
        """
        return jsii.get(self, "tfProperties")


@jsii.data_type(jsii_type="@terrastack/core.ResourceObjectMetadata", jsii_struct_bases=[], name_mapping={'name': 'name'})
class ResourceObjectMetadata():
    def __init__(self, *, name: typing.Optional[str]=None):
        """Metadata associated with this object.

        :param name: The unique, namespace-global, name of this object inside the Kubernetes cluster. Normally, you shouldn't specify names for objects and let the CDK generate a name for you that is application-unique. The names CDK generates are composed from the construct path components, separated by dots and a suffix that is based on a hash of the entire path, to ensure uniqueness. You can supply custom name allocation logic by overriding the ``chart.generateObjectName`` method. If you use an explicit name here, bear in mind that this reduces the composability of your construct because it won't be possible to include more than one instance in any app. Therefore it is highly recommended to leave this unspecified. Default: - an app-unique name generated by the chart

        stability
        :stability: experimental
        """
        self._values = {
        }
        if name is not None: self._values["name"] = name

    @builtins.property
    def name(self) -> typing.Optional[str]:
        """The unique, namespace-global, name of this object inside the Kubernetes cluster.

        Normally, you shouldn't specify names for objects and let the CDK generate
        a name for you that is application-unique. The names CDK generates are
        composed from the construct path components, separated by dots and a suffix
        that is based on a hash of the entire path, to ensure uniqueness.

        You can supply custom name allocation logic by overriding the
        ``chart.generateObjectName`` method.

        If you use an explicit name here, bear in mind that this reduces the
        composability of your construct because it won't be possible to include
        more than one instance in any app. Therefore it is highly recommended to
        leave this unspecified.

        default
        :default: - an app-unique name generated by the chart

        stability
        :stability: experimental
        """
        return self._values.get('name')

    def __eq__(self, rhs) -> bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs) -> bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return 'ResourceObjectMetadata(%s)' % ', '.join(k + '=' + repr(v) for k, v in self._values.items())


@jsii.data_type(jsii_type="@terrastack/core.ResourceObjectProps", jsii_struct_bases=[], name_mapping={'data': 'data', 'metadata': 'metadata'})
class ResourceObjectProps():
    def __init__(self, *, data: typing.Any=None, metadata: typing.Optional["ResourceObjectMetadata"]=None):
        """Options for defining API objects.

        :param data: Data associated with the resource.
        :param metadata: Object metadata. If ``name`` is not specified, an app-unique name will be allocated by the framework based on the path of the construct within thes construct tree.

        stability
        :stability: experimental
        """
        if isinstance(metadata, dict): metadata = ResourceObjectMetadata(**metadata)
        self._values = {
        }
        if data is not None: self._values["data"] = data
        if metadata is not None: self._values["metadata"] = metadata

    @builtins.property
    def data(self) -> typing.Any:
        """Data associated with the resource.

        stability
        :stability: experimental
        """
        return self._values.get('data')

    @builtins.property
    def metadata(self) -> typing.Optional["ResourceObjectMetadata"]:
        """Object metadata.

        If ``name`` is not specified, an app-unique name will be allocated by the
        framework based on the path of the construct within thes construct tree.

        stability
        :stability: experimental
        """
        return self._values.get('metadata')

    def __eq__(self, rhs) -> bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs) -> bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return 'ResourceObjectProps(%s)' % ', '.join(k + '=' + repr(v) for k, v in self._values.items())


class Stack(aws_cdk.core.Construct, metaclass=jsii.JSIIMeta, jsii_type="@terrastack/core.Stack"):
    """
    stability
    :stability: experimental
    """
    def __init__(self, scope: aws_cdk.core.Construct, ns: str) -> None:
        """
        :param scope: -
        :param ns: -

        stability
        :stability: experimental
        """
        jsii.create(Stack, self, [scope, ns])

    @jsii.member(jsii_name="of")
    @builtins.classmethod
    def of(cls, node: aws_cdk.core.Construct) -> "Stack":
        """Finds the stack in which a node is defined.

        :param node: a construct node.

        stability
        :stability: experimental
        """
        return jsii.sinvoke(cls, "of", [node])

    @jsii.member(jsii_name="generateObjectName")
    def generate_object_name(self, resource_object: "ResourceObject") -> str:
        """Generates a app-unique name for an object given it's construct node path.

        Different resource types may have different constraints on names
        (``metadata.name``). The previous version of the name generator was
        compatible with DNS_SUBDOMAIN but not with DNS_LABEL.

        For example, ``Deployment`` names must comply with DNS_SUBDOMAIN while
        ``Service`` names must comply with DNS_LABEL.

        Since there is no formal specification for this, the default name
        generation scheme for kubernetes objects in cdk8s was changed to DNS_LABEL,
        since it’s the common denominator for all kubernetes resources
        (supposedly).

        You can override this method if you wish to customize object names at the
        chart level.

        :param resource_object: The API object to generate a name for.

        stability
        :stability: experimental
        """
        return jsii.invoke(self, "generateObjectName", [resource_object])

    @jsii.member(jsii_name="synthesize")
    def _synthesize(self, session: aws_cdk.core.ISynthesisSession) -> None:
        """Allows this construct to emit artifacts into the cloud assembly during synthesis.

        This method is usually implemented by framework-level constructs such as ``Stack`` and ``Asset``
        as they participate in synthesizing the cloud assembly.

        :param session: -

        stability
        :stability: experimental
        """
        return jsii.invoke(self, "synthesize", [session])

    @builtins.property
    @jsii.member(jsii_name="manifestFile")
    def manifest_file(self) -> str:
        """The name of the stack's YAML file as emitted into the cloud assembly directory during synthesis.

        stability
        :stability: experimental
        """
        return jsii.get(self, "manifestFile")


@jsii.data_type(jsii_type="@terrastack/core.TerraformMetadata", jsii_struct_bases=[], name_mapping={'name': 'name', 'provider_name': 'providerName', 'provider_version': 'providerVersion', 'raw_schema': 'rawSchema', 'schema_type': 'schemaType'})
class TerraformMetadata():
    def __init__(self, *, name: str, provider_name: str, provider_version: str, raw_schema: str, schema_type: "TerraformSchemaType"):
        """
        :param name: 
        :param provider_name: 
        :param provider_version: 
        :param raw_schema: 
        :param schema_type: 

        stability
        :stability: experimental
        """
        self._values = {
            'name': name,
            'provider_name': provider_name,
            'provider_version': provider_version,
            'raw_schema': raw_schema,
            'schema_type': schema_type,
        }

    @builtins.property
    def name(self) -> str:
        """
        stability
        :stability: experimental
        """
        return self._values.get('name')

    @builtins.property
    def provider_name(self) -> str:
        """
        stability
        :stability: experimental
        """
        return self._values.get('provider_name')

    @builtins.property
    def provider_version(self) -> str:
        """
        stability
        :stability: experimental
        """
        return self._values.get('provider_version')

    @builtins.property
    def raw_schema(self) -> str:
        """
        stability
        :stability: experimental
        """
        return self._values.get('raw_schema')

    @builtins.property
    def schema_type(self) -> "TerraformSchemaType":
        """
        stability
        :stability: experimental
        """
        return self._values.get('schema_type')

    def __eq__(self, rhs) -> bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs) -> bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return 'TerraformMetadata(%s)' % ', '.join(k + '=' + repr(v) for k, v in self._values.items())


@jsii.enum(jsii_type="@terrastack/core.TerraformSchemaType")
class TerraformSchemaType(enum.Enum):
    """
    stability
    :stability: experimental
    """
    PROVIDER = "PROVIDER"
    """
    stability
    :stability: experimental
    """
    RESOURCE = "RESOURCE"
    """
    stability
    :stability: experimental
    """
    DATA = "DATA"
    """
    stability
    :stability: experimental
    """

class TfReference(metaclass=jsii.JSIIMeta, jsii_type="@terrastack/core.TfReference"):
    """A Token that represents a CloudFormation reference to another resource.

    If these references are used in a different stack from where they are
    defined, appropriate CloudFormation ``Export``s and ``Fn::ImportValue``s will be
    synthesized automatically instead of the regular CloudFormation references.

    Additionally, the dependency between the stacks will be recorded, and the toolkit
    will make sure to deploy producing stack before the consuming stack.

    This magic happens in the prepare() phase, where consuming stacks will call
    ``consumeFromStack`` on these Tokens and if they happen to be exported by a different
    Stack, we'll register the dependency.

    stability
    :stability: experimental
    """
    def __init__(self) -> None:
        jsii.create(TfReference, self, [])

    @jsii.member(jsii_name="for")
    @builtins.classmethod
    def for_(cls, target: "IReferencableResource", attribute: str, value: typing.Any) -> typing.Any:
        """Return the TfReference for the indicated target.

        Will make sure that multiple invocations for the same target and intrinsic
        return the same TfReference. Because TfReferences accumulate state in
        the prepare() phase (for the purpose of cross-stack references), it's
        important that the state isn't lost if it's lazily created, like so::

            Lazy.stringValue({ produce: () => new TfReference(...) })

        :param target: -
        :param attribute: -
        :param value: -

        stability
        :stability: experimental
        """
        return jsii.sinvoke(cls, "for", [target, attribute, value])


__all__ = ["App", "AppOptions", "IReferencableResource", "ResourceObject", "ResourceObjectMetadata", "ResourceObjectProps", "Stack", "TerraformMetadata", "TerraformSchemaType", "TfReference", "__jsii_assembly__"]

publication.publish()
