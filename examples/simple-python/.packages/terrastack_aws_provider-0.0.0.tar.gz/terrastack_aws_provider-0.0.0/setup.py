import json
import setuptools

kwargs = json.loads("""
{
    "name": "terrastack_aws_provider",
    "version": "0.0.0",
    "description": "@terrastack/aws-provider",
    "license": "Apache-2.0",
    "url": "https://github.com/terrastackio/terrastack",
    "long_description_content_type": "text/markdown",
    "author": "sebastian@korfmann.net",
    "project_urls": {
        "Source": "https://github.com/terrastackio/terrastack"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "terrastack_aws_provider",
        "terrastack_aws_provider._jsii"
    ],
    "package_data": {
        "terrastack_aws_provider._jsii": [
            "aws-provider@0.0.0.jsii.tgz"
        ],
        "terrastack_aws_provider": [
            "py.typed"
        ]
    },
    "python_requires": ">=3.6",
    "install_requires": [
        "jsii~=0.22.0",
        "publication>=0.0.3",
        "aws-cdk.core>=1.27.0, <2.0.0",
        "terrastack>=0.15.0, <0.16.0"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Typing :: Typed",
        "License :: OSI Approved"
    ]
}
""")

with open('README.md') as fp:
    kwargs['long_description'] = fp.read()


setuptools.setup(**kwargs)
